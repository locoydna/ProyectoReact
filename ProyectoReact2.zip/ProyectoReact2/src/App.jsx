import './styles/style.css';                      // ✅ Estilos personalizados
import LoginForm from './components/LoginForm';   // ✅ Componente de login
import RegisterForm from './components/RegisterForm'; // ✅ Componente de registro
import VideoHeader from './components/VideoHeader';   // ✅ Nuevo componente de video con sonido

function App() {
  return (
    <>
      <VideoHeader />  {/* ⬅️ Reemplaza el bloque del iframe */}

      <div className="hover-card">
        <img src="/imagenes/imagen_gif.png" alt="Arte WoW" />
      </div>

      <div className="auth-container">
        <LoginForm />
        <RegisterForm />
      </div>
    </>
  );
}

export default App;
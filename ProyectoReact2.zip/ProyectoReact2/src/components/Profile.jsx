import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/style.css';

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [showStats, setShowStats] = useState(false);
  const [slideIndex, setSlideIndex] = useState(0);

  const slides = [
    '/imagenes/arte_wow.png',
    '/imagenes/Animated_GIF.png',
    '/imagenes/cazador_bestia.png',
    '/imagenes/cazador_bestia_2.png',
    '/imagenes/colina2.0.png',
    '/imagenes/enano_caballero.png'
  ];

  const aleatorio = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min;

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('loggedUser'));
    if (!storedUser) {
      navigate('/');
    } else {
      storedUser.tiempoJugado = `${aleatorio(50, 200)}h`;
      setUser(storedUser);
    }

    const interval = setInterval(() => {
      setSlideIndex(i => (i + 1) % slides.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const cerrarSesion = () => {
    localStorage.removeItem('loggedUser');
    navigate('/');
  };

  return (
    <>
      {/* VIDEO HEADER */}
      <div className="video-header">
        <iframe
          id="ytPlayer"
          className="bg-video"
          src="https://www.youtube.com/embed/NJMgpmY9MOU?start=11&autoplay=1&mute=1&loop=1&playlist=NJMgpmY9MOU&controls=0&modestbranding=1"
          frameBorder="0"
          allow="autoplay; encrypted-media"
          allowFullScreen
        ></iframe>
        <button id="soundBtn" className="sound-btn">🔊 Activar sonido</button>
      </div>

      {/* PERFIL HERO */}
      <div className="profile-hero">
        {/* SIDEBAR */}
        <aside className="profile-sidebar">
          <img src="/imagenes/cazador_bestia.png" className="icono" alt="Avatar" />
          <h2>{user?.characterName} – {user?.realm}</h2>
          <ul className="basic-info">
            <li><strong>Nivel:</strong> 45</li>
            <li><strong>Clase:</strong> {user?.charClass}</li>
            <li><strong>Reino:</strong> {user?.realm}</li>
            <li><strong>Hermandad:</strong> {user?.guild}</li>
            <li><strong>Último login:</strong> {user?.lastLogin}</li>
          </ul>
          <button className="action-btn logout" onClick={cerrarSesion}>Cerrar sesión</button>
        </aside>

        {/* MAIN CONTENT */}
        <section className="profile-main">
          {/* GALERÍA */}
          <div className="gallery">
            <button onClick={() => setSlideIndex(i => (i - 1 + slides.length) % slides.length)}>&lt;</button>
            <img id="slide" src={slides[slideIndex]} alt="Arte WoW" />
            <button onClick={() => setSlideIndex(i => (i + 1) % slides.length)}>&gt;</button>
          </div>

          {/* ESTADÍSTICAS */}
          <div className="profile-stats">
            <button onClick={() => setShowStats(!showStats)} className="action-btn small">
              Mostrar/Ocultar estadísticas
            </button>
            {showStats && (
              <div className="extra-stats">
                <p>Fuerza: {user?.atributos?.fuerza}</p>
                <p>Vitalidad: {user?.atributos?.vitalidad}</p>
                <p>Agilidad: {user?.atributos?.agilidad}</p>
                <p>Inteligencia: {user?.atributos?.inteligencia}</p>
                <p>Tiempo Jugado: {user?.tiempoJugado}</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
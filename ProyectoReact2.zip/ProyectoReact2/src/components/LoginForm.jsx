import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LoginForm() {
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const user = users.find(x => x.username === loginUser && x.password === loginPass);

    if (!user) {
      setMessage("❌ Usuario o contraseña incorrectos.");
      return;
    }

    user.lastLogin = new Date().toLocaleTimeString();
    localStorage.setItem("loggedUser", JSON.stringify(user));
    navigate("/profile");
  };

  return (
    <div className="form-box">
      <h2>Iniciar Sesión</h2>
      <form onSubmit={handleLogin}>
        <input type="text" placeholder="Usuario" value={loginUser} onChange={e => setLoginUser(e.target.value)} required />
        <input type="password" placeholder="Contraseña" value={loginPass} onChange={e => setLoginPass(e.target.value)} required />
        <button type="submit" className="action-btn">Entrar</button>
      </form>
      <p className="message-area">{message}</p>
    </div>
  );
}
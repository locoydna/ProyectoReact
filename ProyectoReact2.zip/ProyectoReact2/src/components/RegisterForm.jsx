import { useState } from 'react';

export default function RegisterForm() {
  const [registerUser, setRegisterUser] = useState('');
  const [registerPass, setRegisterPass] = useState('');
  const [charName, setCharName] = useState('');
  const [realm, setRealm] = useState('');
  const [race, setRace] = useState('');
  const [charClass, setCharClass] = useState('');
  const [message, setMessage] = useState('');

  const hermandades = [
    "Luz Eterna", "Sombras del Vacío", "Alas del Norte",
    "Legión de la Tormenta", "Furia de Dragón", "Vigilantes del Alba",
    "Eco del Destino", "Guardianes del Núcleo"
  ];

  const aleatorio = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min;

  const generarAtributosPorClase = (cls) => {
    switch (cls) {
      case "Guerrero":
      case "Paladín":
        return { fuerza: aleatorio(80, 100), agilidad: aleatorio(30, 60), inteligencia: aleatorio(20, 50), vitalidad: aleatorio(70, 100) };
      case "Mago":
      case "Sacerdote":
        return { fuerza: aleatorio(10, 40), agilidad: aleatorio(30, 50), inteligencia: aleatorio(80, 100), vitalidad: aleatorio(40, 70) };
      case "Cazador":
      case "Pícaro":
        return { fuerza: aleatorio(30, 60), agilidad: aleatorio(80, 100), inteligencia: aleatorio(40, 70), vitalidad: aleatorio(50, 80) };
      default:
        return { fuerza: 60, agilidad: 60, inteligencia: 60, vitalidad: 60 };
    }
  };

  const handleRegister = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem("users")) || [];
    if (users.some(u => u.username === registerUser)) {
      setMessage("⚠️ Usuario ya existe.");
      return;
    }

    const guild = hermandades[Math.floor(Math.random() * hermandades.length)];
    const atributos = generarAtributosPorClase(charClass);

    users.push({
      username: registerUser,
      password: registerPass,
      characterName: charName,
      realm,
      race,
      charClass,
      guild,
      atributos
    });

    localStorage.setItem("users", JSON.stringify(users));
    setMessage("✅ Registro exitoso. Ya puedes iniciar sesión.");
    setRegisterUser('');
    setRegisterPass('');
    setCharName('');
    setRealm('');
    setRace('');
    setCharClass('');
  };

  return (
    <div className="form-box">
      <h2>Registrarse</h2>
      <form onSubmit={handleRegister}>
        <input type="text" placeholder="Usuario" value={registerUser} onChange={e => setRegisterUser(e.target.value)} required />
        <input type="password" placeholder="Contraseña" value={registerPass} onChange={e => setRegisterPass(e.target.value)} required />
        <input type="text" placeholder="Nombre de Personaje" value={charName} onChange={e => setCharName(e.target.value)} required />
        {/* Selects de Reino, Raza y Clase — igual que tu HTML original */}
        {/* Puedes agregarlos con sus options si lo necesitas, o te los puedo dar listos */}
        <button type="submit" className="action-btn">Registrarse</button>
      </form>
      <p className="message-area">{message}</p>
    </div>
  );
}
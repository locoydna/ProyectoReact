import { useEffect, useRef, useState } from 'react';

export default function VideoHeader() {
  const playerRef = useRef(null);
  const [isMuted, setIsMuted] = useState(true);
  const [playerReady, setPlayerReady] = useState(false);

  useEffect(() => {
    let checkCount = 0;

    const waitForPlayer = () => {
      const iframe = document.getElementById('ytPlayer');

      if (window.YT && window.YT.Player && iframe) {
        playerRef.current = new window.YT.Player('ytPlayer', {
          events: {
            onReady: event => {
              event.target.mute();
              setPlayerReady(true);
              console.log("✅ Reproductor inicializado");
            }
          }
        });
      } else {
        checkCount++;
        if (checkCount < 20) setTimeout(waitForPlayer, 300);
        else console.warn("⏳ El reproductor no se pudo inicializar.");
      }
    };

    waitForPlayer();
  }, []);

  const toggleSound = () => {
    if (!playerRef.current || !playerReady) {
      console.warn("🎬 El reproductor aún no está listo para controlar sonido.");
      return;
    }

    if (isMuted) {
      playerRef.current.unMute();
    } else {
      playerRef.current.mute();
    }

    setIsMuted(!isMuted);
  };

  return (
    <div className="video-header">
      <iframe
        id="ytPlayer"
        className="bg-video"
        src="https://www.youtube.com/embed/A2KRoI9bics?autoplay=1&mute=1&loop=1&playlist=A2KRoI9bics&controls=0&modestbranding=1&enablejsapi=1"
        frameBorder="0"
        allow="autoplay; encrypted-media"
        allowFullScreen
        title="Video WoW"
      ></iframe>
      <button className="sound-btn" onClick={toggleSound}>
        {isMuted ? '🔊 Activar sonido' : '🔇 Silenciar'}
      </button>
    </div>
  );
}